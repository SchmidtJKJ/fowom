<?php

if(isset($_POST['like']))
 {
   include("dbKoneksyon.php");

       $id = $_POST['id'];
       $name= $_SESSION['user'];
       $sql = "UPDATE komante SET likes = likes+1 where komanteID = '$id';";
       $addPoints="UPDATE itilizate SET patisipasyonPwen= patisipasyonPwen+1 where userID= '$name';";
       mysqli_query($conn,$addPoints);
       mysqli_query($conn,$sql);
       echo "I have passed the SQL querries";
       header('Location: ' . $_SERVER['HTTP_REFERER']);
       exit();

   }


   if(isset($_POST['dislike']))
    {
      include("dbKoneksyon.php");

          $id = $_POST['id'];
          $name= $_SESSION['user'];
          $sql = "UPDATE komante SET dislike = dislike+1 where komanteID = '$id';";
          $addPoints="UPDATE itilizate SET patisipasyonPwen= patisipasyonPwen+1 where userID= '$name';";
          mysqli_query($conn,$addPoints);
          mysqli_query($conn,$sql);
          echo "I have passed the SQL querries";
          header('Location: ' . $_SERVER['HTTP_REFERER']);
          exit();

      }
