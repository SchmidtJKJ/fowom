<?php
include("dbKoneksyon.php");

echo "Chache!";
 ?>
