<?php

if(isset($_POST['komante']))
 {
   include("dbKoneksyon.php");
     if(isset($_POST['teks']))
     {
       $sql = "INSERT INTO komante (atik, met, kontni, dat, likes, dislike) VALUES (?,?,?,CURRENT_TIMESTAMP(),?,?);";
       $name= $_SESSION['user'];
       $dat=date('d/m/Y h:i:s a', time());
       $query = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($query, $sql))
        {
          header('Location: ' . $_SERVER['HTTP_REFERER']);
          exit();
        }
        else
        {
          $Uid=$_SESSION['user'];
          $z=0;
          $Aid= $_POST['id'];
          $comment = htmlspecialchars($_POST['teks']);
          mysqli_stmt_bind_param($query,"iisii",$Aid,$Uid,$comment,$z,$z);
          mysqli_stmt_execute($query);
          //$_SESSION['diskisyonID'] = $Did;
          $addPoints="UPDATE itilizate SET patisipasyonPwen= patisipasyonPwen+7 where userID= '$name';";
          $addComment = "UPDATE atik SET komante = komante+1 WHERE atikID = '$Aid';";
          mysqli_query($conn,$addPoints);
          mysqli_query($conn,$addComment);
          header('Location: ' . $_SERVER['HTTP_REFERER']);
          exit();

        }
     }
     else
      {
         header("Location: diskisyon.php?ranpliFomNan");
         exit();
       }

   }

   else {
     // code...
     header("Location: diskisyon.php?FormNotSet");
     exit();
   }
 ?>
